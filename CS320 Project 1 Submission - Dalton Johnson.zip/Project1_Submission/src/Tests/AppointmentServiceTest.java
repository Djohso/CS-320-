package Tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.Appointment;
import main.AppointmentService;

import java.util.ArrayList;
import java.util.Date; 

class AppointmentServiceTest {
	
	public static ArrayList<Appointment> appointments = new ArrayList<>();
		AppointmentServiceTest appointmentService = new AppointmentService();
		
		@Test
		public void addValidAppointment() {
			Appointment appointment = new Appointment("123", new Date(), "Description");
			appointmentService.addAppointment(appointment);
			Appointment testAppointment = appoointmentService.getAppointment("123");
			Assertions.assertEquals("Description", testAppointment.getDescription());
		}
		
		@Test
		public void deleteAppointmentTestID() {
			Appointment appointment = new Appointment();
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				appointmentService.deleteAppointment("20");
			});
		}
		
		@Test
		Public void deleteAppointmentTest() {
			Appointment appointment = new Appointment("123", new Date(), "abcd");
			appointmentServcie.addAppointment(appointment);
			appointmentService.deleteAppointment("123");
			}
					
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	

	 
	
	


}
