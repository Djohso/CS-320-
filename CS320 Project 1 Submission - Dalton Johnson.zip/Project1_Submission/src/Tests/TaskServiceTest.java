package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
	
	@Test
	void addTaskServiceTest() {
		taskService = new TaskService();
		taskService.addTask("1234", "Name","description");
	}
	
	@Test
	void updateNameTest() {
		taskService.addTask("1234", "Name","description");
		taskService.updateName("1234", "New Name");
		Assert.assertEquals(Task.getName(). taskService.getTask("1234").equals("New Name"));
		
	}
	
	@Test
	void deleteTaskTest() {
		taskService.addTask("1234", "Name","description");
		Assertions.assertTrue(taskService.deleteTask("1234"));
	}

}
