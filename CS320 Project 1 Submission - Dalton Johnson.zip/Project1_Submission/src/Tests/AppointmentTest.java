package Tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Appointment;

import static org.junit.Assert.assertTrue;

import java.util.Date;



class AppointmentTest {

	
	@Test
	void TestAppointment() {
		Date date = new Date(System.currentTimeMillis());
		Date date2 = new Date(System.currentTimeMillis() - 100000);
		Appointment appointment = new Appointment("12245678910111213", date2 , "ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			assertTrue(appointment.getDate().after(date));
			assertTrue(appointment.getDescription().length() <= 50);
			assertTrue(appointment.getID().length() <= 10);
		});
		
		
	}
	
	
	
	
	@Test
	void testInvalidID() {
		Appointment appointment = new Appointment();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appointment.setID(null);
		});
	}
	
	@Test
	void testInvalidDate() {
		Appointment appointment = new Appointment();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appointment.setID("1829382948937593849396584395839");
		});
	}
	
	@Test
	void testInvalidDescription() {
		Appointment appointment = new Appointment();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appointment.setDescription(null);
		});
	}
	
	
	
	
	
	

}
