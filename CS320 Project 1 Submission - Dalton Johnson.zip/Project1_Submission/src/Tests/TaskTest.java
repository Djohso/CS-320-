package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void TaskTest() {
		Task Task = new Task("1234", "Name", "description");
		Assertions.assertTrue(task.getID().equals("1234"));
		Assertions.assertTrue(task.getName().equals("Name"));
		Assertions.assertTrue(task.getDescription().equals("description"));
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234", "Name", "description");
		});
	}
	
	@Test
	void nullNameTest() {
		Task Task = new Task("1234", "Name", "description");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			task.setName(null);
		});
	}
	
	@Test
	void descriptionTest() {
		Task Task = new Task("1234", "Name", "description");
		Assertions.assertThrows(IllegalArgumentException, () -> {
			task.setDescription(null);
		});
	}

}
