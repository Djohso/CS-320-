package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactClassTest {

	@Test
	void testID() {
		Contact contactID = new Contact("JOE", "Jo","1234", "1234567", "Wonka Factory");
		Assertions.assertTrue(contactID.getID().equals("1234"));
		Assertions.assertTrue(contactID.getAddress().equals("Wonka Factory"));
		Assertions.assertTrue(contactID.getFirstName().equals("JOE"));
		Assertions.assertTrue(contactID.getLastName().equals("Jo"));
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("JOE", "Jo","1234", "1234567", "Wonka Factory");
		});
	}
	
	@Test
	void testPhone() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contactID = new Contact("JOE", "Jo","1234", "1234567", "Wonka Factory");
			contact.setPhone("1234567");
		});
	}
	
	@Test
	void testAddress() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contactID = new Contact("JOE", "Jo","1234", "1234567", "Wonka Factory");
			contact.setAddress("Wonka Factory");
		});
	}
}


	
