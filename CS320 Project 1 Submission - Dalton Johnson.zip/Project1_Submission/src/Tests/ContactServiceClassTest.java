package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import junit.framework.Assert;
import main.ContactServiceClass;
import main.ContactClass;

class ContactServiceClassTest {

	@Test
	void updateFirstNameTest() {
		Contact c = new Contact("JOE", "Jo","1234", "1234567", "Wonka Factory");
		ContactService cs = new ContactService();
		cs.addContact("JOE", "Jo","1234", "1234567", "Wonka Factory");
		cs.updateLastName("1234", "Joh");
		Assert.assertEquals(c.getLastName(), cs.getContact("1234").getLastName());
	}
	
	@Test
	void deleteContactTest() {
		Contact c = new Contact("JOE", "Jo","1234", "1234567", "Wonka Factory");
		Assertions.assertTrue(contactService.removeContact("1234"));
	}
	
	@Test
	void updateAddressTest() {
		Contact c = new Contact("JOE", "Jo","1234", "1234567", "Wonka Factory");
		contactService.updateAddress("1234", "New Address");
	}
	
	
	
	


}
