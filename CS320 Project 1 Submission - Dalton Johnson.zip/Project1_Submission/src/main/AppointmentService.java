
/*
 * Class Requirements
 * 
 * the appointment service shall be able to add appointments with a unique ID
 * 
 * the appointment service shall be able to delete appointments with a unique ID
 * 
 */




package main;

import java.util.ArrayList;

public class AppointmentService {
	
	private ArrayList<Appointment> appointments;
	public AppointmentService() {
		appointments = new ArrayList<>();
	}
	
	public void addAppointment(Appointment a) {
		for(Appointment appointment: appointments) {
			if(appointment.getID().equalsIgnoreCase(a.getID()))
				return;
		}
		appointments.add(a);
	}
	
	public boolean deleteAppointment(String ID) {
		for(Appointment appointment: appointments) {
			if(appointment.getID().equalsIgnoreCase(ID)) {
				appointments.remove(appointment);
				return true;
			}	
		}
		return false;

	}
}