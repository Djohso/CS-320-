package main;


/*
 * Requirements:
 *  - Task Object shall have unique task ID String no longer than 10 characters 
 *  	shall not be null and shall not be updatable
 *  -Task Object shall have a required name String field that cannot be longer than 20 characters
 *  	shall not be null
 *  -Task Object shall have a required description String field that cannot be longer than 50 characters
 *  	shall not be null
 */
public class Task {
	
	private String ID;
	private String name;
	private String description;
	
	public Task (String ID, String name, String description) {
		
		if(ID == null || ID.length() >10 ) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name");
		}
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
	}
	
	public String getID() {
		return ID;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
 //resubmission 
	
	

}
