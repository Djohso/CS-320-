package main;

import java.util.ArrayList;

public class ContactServiceClass {

		private ArrayList<ContactClass> contacts;
		public ContactServiceClass() {
			contacts = new ArrayList<>();
		}
		
		public ArrayList<ContactClass> getContacts() {
			return contacts;
		}
		
		public ContactClass getContact(String ID) {
			for (ContactClass contact : contacts) {
				if(contact.getID().equalsIgnoreCase(ID)) 
					return contact;
			}
			return null;
		}
		
		public void addContact (ContactClass c) {
			for (ContactClass contact:contacts) {
				//iterates through to check for duplicate IDs already in the system
				if(contact.getID().equalsIgnoreCase(c.getID()))
						return;
			}
			contacts.add(c);
		}
		
		public boolean removeContact(String ID) {
			for(ContactClass contact:contacts) {
				if(contact.getID().equalsIgnoreCase(ID)) {
					contacts.remove(contact);
					return true;
				}
			}
			return false;
		}
		
		public boolean updateFirstName(String ID, String firstName) {
			for(ContactClass contact:contacts) {
				if(contact.getID().equalsIgnoreCase(ID)) {
					contact.setFirstName(firstName);
					return true;
				}
			}
			return false;
		}
		
		public boolean updateLastName(String ID, String lastName) {
			for(ContactClass contact:contacts) {
				if(contact.getID().equalsIgnoreCase(ID)) {
					contact.setLastName(lastName);
					return true;
				}
			}
			return false;
		}
		
		public boolean updateAddress(String ID, String updatedAddress) {
			for(ContactClass contact:contacts) {
				if(contact.getID().equalsIgnoreCase(ID)) {
					contact.setAddress(updatedAddress);
					return true;
				}
			}
			return false;
		}
		
		public boolean updatePhone (String ID, String phone) {
			for(ContactClass contact:contacts) {
				if(contact.getID().equalsIgnoreCase(ID)) {
					contact.setPhone(phone);
					return true;
				}
			}
			return false;
		}
		
		
	
}
