
/*
 * The task service shall be able to add task with ID 
 * 
 * The task service shall be able to delete tasks per ID
 * 
 * The task service shall be able to update task fields
 *		Name, Description
 */

package main;

import java.util.ArrayList;

public class TaskService {

	private ArrayList<Task> tasks;
	public TaskService() {
		tasks = new ArrayList<>();
	}
	
	public void addTask(Task t) {
		for(Task task:tasks) {
			if(task.getID().equalsIgnoreCase(t.getID())) 
				return;
		}
		tasks.add(t);
	}
	
	public boolean deleteTask(String ID) {
		for(Task task:tasks) {
			if(task.getID().equalsIgnoreCase(ID)) {
				tasks.remove(task);
				return true;
			}
		}
		return false;
	}
	
	public boolean updateName(String ID, String Name) {
		for(Task task:tasks) {
			if(task.getID().equalsIgnoreCase(ID)) {
				task.setName(Name);
				return true;
			}
			}
		return false;
	}
	
	public boolean updateDescription(String ID, String Description) {
		for(Task task:tasks) {
			if(task.getID().equalsIgnoreCase(ID)) {
				task.setDescription(Description);
				return true;
			}
			}
		return false;
	
	}
}
