/*
 * Class Requirements
 * 
 * the appointment service shall be able to add appointments with a unique ID
 * 
 * the appointment service shall be able to delete appointments with a unique ID
 * 
 */




package main;

import java.util.Date;

public class Appointment{
	
	private String ID;
	private Date date;
	private String description;
	
	public Appointment(String ID, Date date, String description) {
		if(date == null || date.before(new Date(System.currentTimeMillis()))) {
			throw new IllegalArgumentException("Invalid Date");
		}
		
		if(ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
	}
	
	public Appointment() {
		
	}
	
	public Date getDate() {
		return date;
	}
	
	public String getID() {
		return ID;
	}
	
	public String getDescription() {
		return description;
	}
	
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public void setID(String ID) {
		this.ID = ID;
	}
	

}