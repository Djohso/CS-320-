package main;

public class ContactClass {
	
	private String firstName;
	private String ID;
	private String lastName;
	private String phone;
	private String address;
	
	

	public ContactClass (String firstName, String lastName,String ID, String phone, String address) {
		
		if(firstName == null || firstName.length()>10) {
			throw new IllegalArgumentException("Invalid Name");
		}
		if(lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid Name");
		}
		if(ID == null || ID.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if(phone == null || phone.length()!=10) {
			throw new IllegalArgumentException("Invalid Phone");
		}
		if(address == null || firstName.length()>30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		
		
		
	}
		
		//get functions to return requested values
		
		public String getFirstName() {
			return firstName;
		}
		
		public String getLastName() {
			return lastName;
		}
		
		public String getID() {
			return ID;
		}
		
		public String getPhone() {
			return phone;
		}
		
		public String getAddress() {
			return address;
		}
		
		//set functions to store values , ID is not included because it will only be set once
		
		public void setFirstName (String firstName) {
			this.firstName = firstName;
		}
		
		public void setLastName (String lastName) {
			this.lastName = lastName;
		}
		
		public void setPhone(String phone) {
			this.phone = phone;
		}
		
		public void setAddress(String address) {
			this.address = address;
		}
		
		
	
	}
	


